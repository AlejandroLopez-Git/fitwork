import email
from django import forms

class RegisterForm(forms.Form):
    nombre = forms.CharField(required=True,
                            min_length=4, max_length=50,
                            widget=forms.TextInput(attrs={
                                'class': "form-control",
                                'id': "nombre"
                            }))
    correoElectronico = forms.EmailField(required=True,
                                        widget=forms.EmailInput(attrs={
                                            'class': "form-control",
                                            'id': "correoElectronico",
                                            'placeholder': 'ejemplo@gmail.com'
                                        }))
    tipoIdentificacion = forms.CharField(required=True,
                                        min_length=4, max_length=50,
                                        widget=forms.TextInput(attrs={
                                            'class': "form-control",
                                            'id': "tipoIdentificacion"
                                        }))
    genero = forms.CharField(required=True,
                            min_length=4, max_length=50,
                            widget=forms.TextInput(attrs={
                                'class': "form-control",
                                'id': "genero"
                            }))
    edad = forms.CharField(required=True,
                            min_length=4, max_length=50,
                            widget=forms.TextInput(attrs={
                                'class': "form-control",
                                'id': "edad"
                            }))
    password = forms.CharField(required=True,
                                min_length=4, max_length=50,
                                widget=forms.PasswordInput(attrs={
                                    'class': "form-control",
                                    'id': "password"
                                }))
    passwordConfirm = forms.CharField(required=True,
                            min_length=4, max_length=50,
                            widget=forms.PasswordInput(attrs={
                                'class': "form-control",
                                'id': "passwordConfirm"
                            }))                                