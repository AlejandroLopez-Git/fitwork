#from django.http import HttpResponse
from django.shortcuts import render
from django.shortcuts import redirect
from django.contrib.auth import login
from django.contrib.auth import logout
from django.contrib.auth import authenticate
from django.contrib import messages

from .forms import RegisterForm

def index(request):
    return render(request, 'index.html', {
        #Context
    })
    
#def login(request):
 #   return render(request, 'login.html', {
        #Context
  #  })

def hola_mundo(request):
    return render(request, 'hola_mundo.html', {

    })

def inicio_cliente(request):
    return render(request, 'pagina_inicio_cliente.html', {
        
    })

def registro_cliente(request):
    form = RegisterForm()

    if  request.method == 'POST' and form.is_valid():
        nombre = form.cleaned_data.get('nombre')
        correoElectronico = form.cleaned_data.get('correoElectronico')
        tipoIdentificacion = form.cleaned_data.get('tipoIdentificacion')
        genero = form.cleaned_data.get('genero')
        edad = form.cleaned_data.get('edad')
        password = form.cleaned_data.get('password')
        passwordConfirm = form.cleaned_data.get('passwordConfirm')

        print(nombre)
        print(correoElectronico)
        print(tipoIdentificacion)
        print(genero)
        print(edad)
        print(password)
        print(passwordConfirm)

    return render(request, 'registro_cliente.html', {

    })

def login_view(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(username=username, password=password)
        if user:
            login(request, user)
            messages.success(request, 'Bienvenido {}'.format(user.username))
            return redirect('inicio_cliente')
        else:
            messages.error(request, 'Usuario o contraseña incorrectos')
    return render(request, 'login.html',{
        
    })

def inicioregistro_view(request):
    if request:
        
        return render(request, 'pagina_inicio_registro.html', {
        
    })

def logout_view(request):
    logout(request)
    messages.success(request, 'Sesión finalizada')
    return redirect('login')
